import java.util.Arrays;

public class Main {
    public static void main(String[] args) {
         int[] array = {1, 6, 12, 3, 10, 15};
       boolean sorted = false;

         while (!sorted){
             sorted = true;

        for (int i = 0; i < array.length -1; i++) {
            int i1 = array[i];
            if (array[i] > array[i + 1]){
                sorted = false;

                array[i] = array[i + 1];
                array[i + 1] = i1;
            }
                }
             System.out.println(Arrays.toString(array));
            }

        }


            }

