public class Main {
    public static void main(String[] args) {

        int[] array = {1, 2, 3, 0, 12};

        boolean check = true;

        for (int i = 1; i < array.length; i++) {
            if(array[i] <= array[i-1]){
                check = false;
                break;
            }
        }
        if(check){
            System.out.println("Массив c возрастающей последовательностью элементов");
        } else {
            System.out.println("Массив с не возрастающей последовательностью элементов");
        }
    }
}

