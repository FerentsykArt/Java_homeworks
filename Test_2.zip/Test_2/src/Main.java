import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        //Ввод в консоль
        System.out.println("Введите слово(а)");
        String userInput = scanner.nextLine();
        //Начальное количество слов
        int count = 0;

        //Если ввели хотя бы одно слово начинаем считать.
        if(userInput.length() != 0){
            count++;
            //Проверяем пробел ли это
            for (int i = 0; i < userInput.length(); i++) {
                if(userInput.charAt(i) == ' '){
                    //Если пробел - увеличиваем количество слов на 1
                    count++;
                }
            }
        }

        System.out.println("Количество введенных слов " + count);
    }
}