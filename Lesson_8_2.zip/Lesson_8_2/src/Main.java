import java.util.Scanner;

public class Main {
    public static void main(String[] args) {



        Scanner scanner = new Scanner(System.in);
        System.out.println("Введите количество уровней");
        int userInput = scanner.nextInt();

        /*String s = "";
        for (int i = 1; i <= 10; i++){
            System.out.println(s += "8");*/
        String s = " ";
        char g = '^';
        for (int i = 1; i <= userInput; i++) {
            System.out.println(s += g) ;

        }
    }
}